import { useEffect, useState } from "react";

export const useTypingMetrics = (typedWords: number, startTime: any) => {
  const [wpm, setWpm] = useState(0);
  // const [initialTypedWords, setInitialTypedWords] = useState(0);

  useEffect(() => {
    let interval: any = null;
    if (startTime) {
      // setInitialTypedWords(typedWords);
      interval = setInterval(() => {
        const elapsedTime = (Date.now() - startTime) / 1000 / 60;
        console.log(startTime);
        
        if (elapsedTime > 0) {
          setWpm(Math.round(typedWords / elapsedTime));
          console.log(wpm);
          
          // if (typedWords.length) {
          //   clearInterval(interval);
          // } else {
          
          // }
        }
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [typedWords]);

  return wpm;
};
