import { RefObject, useState } from "react";
import { useKeyHandler } from "./useKeyHandler";
import { useTypingMetrics } from "./useTypingMetrics";

export const useHandleKey = (ignoreRefs: RefObject<HTMLInputElement>[]) => {
  const [typedWords, setTypedWords] = useState(0);
  const [startTime, setStartTime] = useState<number | null>(null);

  useKeyHandler(ignoreRefs, typedWords, setTypedWords, startTime, setStartTime);
  const wpm = useTypingMetrics(typedWords, startTime);

  return { wpm };
};
